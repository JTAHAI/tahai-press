# Modern Daily

Compact contemporary reporting with a clean utility masthead and fast-scanning story grid.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
