# High Contrast

Maximum visual separation, clear focus, and low-ambiguity component boundaries.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
