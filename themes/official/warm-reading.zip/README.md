# Warm Reading Edition

Low-glare warm surfaces for long reading, understated cards, and print-like rhythm.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
