# Community Weekly

Approachable neighborhood reporting with generous cards, evergreen ink, and community callouts.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
