# Investigative Journal

Long-form accountability reporting with restrained burgundy, spacious reading, and document emphasis.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
