# Arts and Culture

Expressive arts reporting with editorial plum, gallery-forward cards, and a relaxed reading rhythm.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
