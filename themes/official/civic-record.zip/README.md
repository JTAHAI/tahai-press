# Civic Record

Source-forward public-record presentation with compact docket cards and structured document hierarchy.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
