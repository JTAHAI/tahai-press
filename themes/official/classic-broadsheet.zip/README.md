# Classic Broadsheet

Traditional newspaper hierarchy with warm paper, formal rules, and a lead-first front page.

This declarative package styles TAHAI Press layout contracts without replacing publishing logic.
